// Variables

// Menu -> Run -> Run With out Debugging

let message = "Hello, World!";
const PI = 3.14;

// Function
function greet(name) {
  return `Hello, ${name}!`;
}

// Output
console.log(greet("Balaji")); // Hello, Alice!
